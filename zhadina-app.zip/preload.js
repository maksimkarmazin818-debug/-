const { contextBridge, ipcRenderer } = require('electron');

contextBridge.exposeInMainWorld('native', {
  toggleFullscreen: () => ipcRenderer.send('toggle-fullscreen'),
  openOverlay: () => ipcRenderer.send('open-overlay'),
  quit: () => ipcRenderer.send('quit'),
  overlayFlushed: () => ipcRenderer.send('overlay-flushed'),
  onCursor: (cb) => ipcRenderer.on('cursor', (_e, x, y) => cb(x, y)),
  onOverlayQuit: (cb) => ipcRenderer.on('overlay-quit', () => cb()),
  onOverlayClosed: (cb) => ipcRenderer.on('overlay-closed', () => cb())
});
