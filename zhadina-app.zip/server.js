'use strict';
const express = require('express');
const http = require('http');
const { Server } = require('socket.io');
const path = require('path');
const app = express();
const server = http.createServer(app);
const io = new Server(server, { cors: { origin: '*' }, transports: ['websocket', 'polling'] });
const PORT = process.env.PORT || 3000;
app.use(express.static(__dirname));
app.get('/health', (_req, res) => res.json({ ok: true, game: 'Zhadina Private Rooms' }));
const rooms = new Map();
const alphabet = 'ABCDEFGHJKLMNPQRSTUVWXYZ23456789';
const coinTypes = [{v:1,r:10,c:'#d98a3d',w:58},{v:3,r:11,c:'#dfe7ee',w:26},{v:10,r:13,c:'#ffc93c',w:13},{v:25,r:12,c:'#5eead4',w:3}];
function code(){let s;do{s='';for(let i=0;i<6;i++)s+=alphabet[Math.floor(Math.random()*alphabet.length)];}while(rooms.has(s));return s;}
function newCoin(){let n=Math.random()*100,t=coinTypes[0];for(const x of coinTypes){n-=x.w;if(n<=0){t=x;break;}}return {id:Math.random().toString(36).slice(2),x:.04+Math.random()*.92,y:.14+Math.random()*.8,v:t.v,r:t.r,c:t.c,life:18};}
function publicState(r){return {room:r.code,started:r.started,ended:r.ended,time:Math.max(0,r.time),players:r.players.map(p=>({id:p.id,nick:p.nick,x:p.x,y:p.y,score:p.score})),coins:r.coins.map(c=>({...c}))};}
function sendState(r){io.to(r.code).emit('room:update',publicState(r));}
function startRoom(r){if(r.started||r.players.length!==2)return;r.started=true;r.time=60;r.last=Date.now();r.coins=[];for(let i=0;i<26;i++)r.coins.push(newCoin());io.to(r.code).emit('room:started');sendState(r);}
function removePlayer(socket){const code=socket.data.room;if(!code)return;const r=rooms.get(code);socket.data.room=null;if(!r)return;r.players=r.players.filter(p=>p.id!==socket.id);socket.leave(code);if(r.players.length===0){clearInterval(r.timer);rooms.delete(code);}else{r.started=false;r.ended=false;r.time=60;r.coins=[];io.to(code).emit('room:error',{message:'Друг отключился. Комната ждёт нового игрока.'});sendState(r);}}
function joinRoom(socket,room,nick,create,cb){if(typeof cb!=='function')return;try{removePlayer(socket);let r;if(create){const c=code();r={code:c,players:[],coins:[],started:false,ended:false,time:60,last:Date.now(),timer:null};rooms.set(c,r);r.timer=setInterval(()=>tick(r),50);}else{r=rooms.get(String(room||'').toUpperCase());if(!r)return cb({ok:false,error:'Комната не найдена. Проверь код.'});if(r.players.length>=2)return cb({ok:false,error:'В комнате уже два игрока.'});if(r.started)return cb({ok:false,error:'Этот матч уже начался.'});}
const p={id:socket.id,nick:String(nick||'Игрок').replace(/[<>]/g,'').trim().slice(0,16)||'Игрок',x:r.players.length===0?.18:.82,y:.5,score:0,lastMove:0};r.players.push(p);socket.join(r.code);socket.data.room=r.code;const response={ok:true,room:r.code,playerId:p.id,players:r.players.map(q=>({id:q.id,nick:q.nick,x:q.x,y:q.y,score:q.score})),coins:r.coins,started:r.started};cb(response);if(r.players.length===2)startRoom(r);else sendState(r);
}catch(e){cb({ok:false,error:'Не удалось создать комнату.'});}}
function tick(r){if(!rooms.has(r.code)||!r.started||r.ended)return;const now=Date.now(),dt=Math.min(.1,(now-r.last)/1000);r.last=now;r.time-=dt;if(r.coins.length<32&&Math.random()<.7)r.coins.push(newCoin());for(const c of r.coins)c.life-=dt;r.coins=r.coins.filter(c=>c.life>0);for(const p of r.players){for(let i=r.coins.length-1;i>=0;i--){const c=r.coins[i];const dx=(p.x-c.x)*1.45,dy=p.y-c.y;if(Math.hypot(dx,dy)<.047){p.score+=c.v;r.coins.splice(i,1);}}}if(r.time<=0){r.time=0;r.ended=true;io.to(r.code).emit('room:ended',publicState(r));}sendState(r);}
io.on('connection',socket=>{
 socket.on('room:create',(d,cb)=>joinRoom(socket,'',d?.nick,true,cb));
 socket.on('room:join',(d,cb)=>joinRoom(socket,d?.room,d?.nick,false,cb));
 socket.on('player:move',d=>{const r=rooms.get(socket.data.room);if(!r||!r.started||r.ended||!d)return;const p=r.players.find(x=>x.id===socket.id);if(!p)return;const now=Date.now();if(now-p.lastMove<25)return;p.lastMove=now;p.x=Math.max(.025,Math.min(.975,Number(d.x)||.5));p.y=Math.max(.12,Math.min(.96,Number(d.y)||.5));});
 socket.on('room:leave',()=>removePlayer(socket));socket.on('disconnect',()=>removePlayer(socket));
});
server.listen(PORT,'0.0.0.0',()=>console.log(`Жадина private server listening on ${PORT}`));
