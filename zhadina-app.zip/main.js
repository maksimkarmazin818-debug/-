const { app, BrowserWindow, ipcMain, screen, globalShortcut } = require('electron');
const path = require('path');

let main = null;
let overlay = null;
let cursorTimer = null;
let closing = false;
const QUIT_KEY = 'CommandOrControl+Alt+Q';

const webPreferences = {
  preload: path.join(__dirname, 'preload.js'),
  contextIsolation: true,
  nodeIntegration: false,
  autoplayPolicy: 'no-user-gesture-required'
};

function createMain() {
  main = new BrowserWindow({
    width: 1280, height: 800, minWidth: 900, minHeight: 620,
    backgroundColor: '#14102b', title: 'Жадина', autoHideMenuBar: true,
    webPreferences
  });
  main.loadFile('index.html');
  main.on('closed', () => { main = null; });
}

// Прозрачное окно поверх рабочего стола. Клики проходят сквозь него,
// а положение курсора мы сами передаём в игру.
function openOverlay() {
  if (overlay) return;
  const b = screen.getPrimaryDisplay().bounds;
  overlay = new BrowserWindow({
    x: b.x, y: b.y, width: b.width, height: b.height,
    transparent: true, frame: false, resizable: false, movable: false,
    hasShadow: false, skipTaskbar: true, focusable: false, alwaysOnTop: true,
    backgroundColor: '#00000000', show: false,
    webPreferences
  });
  overlay.setAlwaysOnTop(true, 'screen-saver');
  overlay.setIgnoreMouseEvents(true);
  overlay.loadFile('index.html', { query: { overlay: '1' } });
  overlay.webContents.once('did-finish-load', () => {
    if (overlay && !overlay.isDestroyed()) overlay.showInactive();
  });
  if (main) main.hide();

  cursorTimer = setInterval(() => {
    if (!overlay || overlay.isDestroyed()) return;
    const p = screen.getCursorScreenPoint();
    overlay.webContents.send('cursor', p.x - b.x, p.y - b.y);
  }, 16);

  globalShortcut.register(QUIT_KEY, closeOverlay);

  overlay.on('closed', () => {
    overlay = null;
    closing = false;
    clearInterval(cursorTimer);
    globalShortcut.unregister(QUIT_KEY);
    if (main) {
      main.show();
      main.webContents.send('overlay-closed');
    }
  });
}

function closeOverlay() {
  if (!overlay || overlay.isDestroyed() || closing) return;
  closing = true;
  overlay.webContents.send('overlay-quit'); // игра сохранит монеты и ответит overlay-flushed
  setTimeout(() => { if (overlay && !overlay.isDestroyed()) overlay.close(); }, 1500);
}

ipcMain.on('toggle-fullscreen', () => { if (main) main.setFullScreen(!main.isFullScreen()); });
ipcMain.on('open-overlay', openOverlay);
ipcMain.on('overlay-flushed', () => { if (overlay && !overlay.isDestroyed()) overlay.close(); });
ipcMain.on('quit', () => app.quit());

app.whenReady().then(createMain);
app.on('window-all-closed', () => app.quit());
app.on('will-quit', () => globalShortcut.unregisterAll());
